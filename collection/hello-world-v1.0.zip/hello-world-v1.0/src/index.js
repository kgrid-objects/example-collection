function welcome(inputs){
  name = inputs.name;
  return "Welcome to Knowledge Grid, " + name;
}

// module.exports = welcome
