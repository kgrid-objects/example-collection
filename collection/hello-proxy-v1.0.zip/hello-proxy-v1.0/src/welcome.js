function welcome(inputs){
  let name = inputs.name;
  return "Welcome to Knowledge Grid, " + name;
}

module.exports = welcome
